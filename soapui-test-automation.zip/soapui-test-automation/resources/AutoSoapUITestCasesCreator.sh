#!/bin/sh
echo OFF

OPTS_DIR=$1
export OPTS_DIR

UTILS_LIB=..\target\*:..\target\dependency\*

if [ -z "$3" ]; then
  echo "No additional classpath is provided, execution with continue with default."
else
  UTILS_LIB=$UTILS_LIB:$3
fi
export UTILS_LIB

if [ -z "$JAVA_HOME" ]; then
  echo "JAVA_HOME is not set, please set the environment variable and try again!"
  exit 1
fi
export JAVA_HOME

if [ -z "$2" ] || [ "$2" == "1" ] || [ "$2" == "3" ]; then
# 1) execute the utility to create Test plan using Swagger JSON doc
echo "Creating test plan! ..."
"$JAVA_HOME/bin/java" -DTestCaseType=$TestCaseType -classpath "$UTILS_LIB/*:$UTILITY_HOME/swagger-parser/*:$UTILITY_HOME/swagger-parser/lib/*" soapui.test.automation.service.TestPlanCreator $OPTS_DIR
echo "Test plan creation completed!"
fi


if [ -z "$2" ] || [ "$2" == "2" ] || [ "$2" == "3" ]; then
# 2) execute the utility to create SOAP-UI test cases using Test plan
echo "Creating soap-ui test cases! ..."
"$JAVA_HOME/bin/java" -Dsoapui.home=$SOAPUI_HOME -classpath "$UTILS_LIB/*:$SOAPUI_HOME/lib/*:$SOAPUI_HOME/bin/*" soapui.test.automation.service.SoapUITestCaseCreator ./TestPlans
echo "soap-ui test cases creation completed!"
fi
