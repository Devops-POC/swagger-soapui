1) Start with maven build to create the utility jar file and download the dependencies.
 => mvn clean package org.apache.maven.plugins:maven-dependency-plugin:2.10:copy-dependencies
 
2) Execute the batch or shell script to run the utility to convert the Swagger JSON document to SOAPUI test script
 => ./resources/AutoSoapUITestCasesCreator.<bat/sh>
 - set JAVA_HOME before executing the script
 command syntax:
 AutoSoapUITestCasesCreator.bat/sh <path of Swagger JSON> [option: 1|2|3] [Additional classpath]
 - option: This is optional parameter, the default value is 3
	1:- Create only the test plan for the specified JSONs
	2:- Create only the SOPAUI script from existing test plan, precondition for this is that test plan should already be created
	3:- Create both test plan as well as SOAPUI test script 

 - Additional classpath: In case you need to pass some additional classpath to the utility execution, this is a optional parameter.
 
 Command example:
 AutoSoapUITestCasesCreator.bat ..\sampleJson
 
 This utility will guide you through to execute it.
 
3) It has some sample Swagger JSON file at ./sampleJson