package soapui.test.automation.bean;

public class TestCaseCount {
	int count = 1;

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public int increamentCount() {
		return this.count++;
	}

}
