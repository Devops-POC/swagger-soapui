package soapui.test.automation.bean;

import java.util.ArrayList;
import java.util.List;

public class SoapUITestCaseStruct {

	private String apiName;
	private String testCaseId;
	private List<SoapUITestStepStruct> testSteps = new ArrayList<SoapUITestStepStruct>();

	public String getApiName() {
		return apiName;
	}

	public void setApiName(String apiName) {
		this.apiName = apiName;
	}

	public String getTestCaseId() {
		return testCaseId;
	}

	public void setTestCaseId(String testCaseId) {
		this.testCaseId = testCaseId;
	}

	public List<SoapUITestStepStruct> getTestSteps() {
		return testSteps;
	}

	public void setTestSteps(List<SoapUITestStepStruct> testSteps) {
		this.testSteps = testSteps;
	}

	public void addTestStep(SoapUITestStepStruct testStep) {
		this.testSteps.add(testStep);
	}
}
