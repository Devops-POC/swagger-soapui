package soapui.test.automation.bean.ms;

import java.util.ArrayList;
import java.util.List;

public class MicroServiceInfo {

	private String name;
	private String description;
	private String host;
	private String basePath;
	private List<String> consumes;
	private List<String> produces;
	private List<RestFullAPIInfo> apis = new ArrayList<RestFullAPIInfo>();

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public String getBasePath() {
		return basePath;
	}

	public void setBasePath(String basePath) {
		this.basePath = basePath;
	}

	public List<String> getConsumes() {
		return consumes;
	}

	public void setConsumes(List<String> consumes) {
		this.consumes = consumes;
	}

	public List<String> getProduces() {
		return produces;
	}

	public void setProduces(List<String> produces) {
		this.produces = produces;
	}

	public List<RestFullAPIInfo> getApis() {
		return apis;
	}

	public void setApis(List<RestFullAPIInfo> apis) {
		this.apis = apis;
	}

	public void addApi(RestFullAPIInfo api) {
		this.apis.add(api);
	}

}
