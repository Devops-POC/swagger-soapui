package soapui.test.automation.bean.ms;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class RestFullAPIInfo {
	private String name;
	private String description;
	private String data;
	private String uri;
	private String baseUri;
	private List<String> consumes;
	private List<String> produces;
	private List<Parameter> parameters;
	private Map<String, Response> responses;
	private String httpMethod;
	private List<String> headers = new ArrayList<String>();
	private List<String> pathVariables = new ArrayList<String>();
	private List<String> requestParams = new ArrayList<String>();

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getUri() {
		return uri;
	}

	public void setUri(String uri) {
		this.uri = uri;
	}

	public String getBaseUri() {
		return baseUri;
	}

	public void setBaseUri(String baseUri) {
		this.baseUri = baseUri;
	}

	public List<String> getConsumes() {
		return consumes;
	}

	public void setConsumes(List<String> consumes) {
		this.consumes = consumes;
	}

	public List<String> getProduces() {
		return produces;
	}

	public void setProduces(List<String> produces) {
		this.produces = produces;
	}

	public List<Parameter> getParameters() {
		return parameters;
	}

	public void setParameters(List<Parameter> parameters) {
		this.parameters = parameters;
	}

	public Map<String, Response> getResponses() {
		return responses;
	}

	public void setResponses(Map<String, Response> responses) {
		this.responses = responses;
	}

	public String getHttpMethod() {
		return httpMethod;
	}

	public void setHttpMethod(String httpMethod) {
		this.httpMethod = httpMethod;
	}

	public List<String> getHeaders() {
		return headers;
	}

	public void setHeaders(List<String> headers) {
		this.headers = headers;
	}

	public void addHeader(String header) {
		this.headers.add(header);
	}

	public List<String> getPathVariables() {
		return pathVariables;
	}

	public void setPathVariables(List<String> pathVariables) {
		this.pathVariables = pathVariables;
	}

	public void addPathVariable(String pathVariable) {
		this.pathVariables.add(pathVariable);
	}

	public List<String> getRequestParams() {
		return requestParams;
	}

	public void setRequestParams(List<String> requestParams) {
		this.requestParams = requestParams;
	}

	public void addRequestParam(String requestParam) {
		this.requestParams.add(requestParam);
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}
}
