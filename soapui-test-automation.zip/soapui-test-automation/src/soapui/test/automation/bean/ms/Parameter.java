package soapui.test.automation.bean.ms;

public class Parameter {

	private String name;
	private String in;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getIn() {
		return in;
	}

	public void setIn(String in) {
		this.in = in;
	}

}
