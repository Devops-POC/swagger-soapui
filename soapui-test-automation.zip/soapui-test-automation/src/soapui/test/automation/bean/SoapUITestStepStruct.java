package soapui.test.automation.bean;

public class SoapUITestStepStruct {
	private String testCaseId;
	private String testStep;
	private String url;
	private String httpMethod;
	private String[] requestParams;
	private String requestBody;
	private String[] headers;
	private AuthBean auth;
	private String httpResponseCode;

	public SoapUITestStepStruct(String testCaseId, String testStep, String url,
			String httpMethod, String[] requestParams, String requestBody,
			String[] headers, AuthBean auth, String httpResponseCode) {
		super();
		this.testCaseId = testCaseId;
		this.testStep = testStep;
		this.url = url;
		this.httpMethod = httpMethod;
		this.requestParams = requestParams;
		this.requestBody = requestBody;
		this.headers = headers;
		this.auth = auth;
		this.httpResponseCode = httpResponseCode;
	}

	public String getTestCaseId() {
		return testCaseId;
	}

	public void setTestCaseId(String testCaseId) {
		this.testCaseId = testCaseId;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getHttpMethod() {
		return httpMethod;
	}

	public void setHttpMethod(String httpMethod) {
		this.httpMethod = httpMethod;
	}

	public String getRequestBody() {
		return requestBody;
	}

	public void setRequestBody(String requestBody) {
		this.requestBody = requestBody;
	}

	public AuthBean getAuth() {
		return auth;
	}

	public void setAuth(AuthBean auth) {
		this.auth = auth;
	}

	public String getHttpResponseCode() {
		return httpResponseCode;
	}

	public void setHttpResponseCode(String httpResponseCode) {
		this.httpResponseCode = httpResponseCode;
	}

	public String[] getRequestParams() {
		return requestParams;
	}

	public void setRequestParams(String[] requestParams) {
		this.requestParams = requestParams;
	}

	public String[] getHeaders() {
		return headers;
	}

	public void setHeaders(String[] headers) {
		this.headers = headers;
	}

	public String getTestStep() {
		return testStep;
	}

	public void setTestStep(String testStep) {
		this.testStep = testStep;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return String
				.format("{ testCaseId=%s, testStep=%s, url=%s, httpMethod=%s, requestParams=%s, requestBody=%s, headers=%s, auth=%s, httpResponseCode=%s",
						this.testCaseId, this.testStep, this.url,
						this.httpMethod, this.requestParams, this.requestBody,
						this.headers, this.auth, this.httpResponseCode);
	}
}
