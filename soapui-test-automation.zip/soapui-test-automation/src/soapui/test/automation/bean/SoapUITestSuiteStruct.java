package soapui.test.automation.bean;

import java.util.ArrayList;
import java.util.List;

public class SoapUITestSuiteStruct {
	private String microServiceName;
	private String apiName;
	private List<SoapUITestCaseStruct> testCases= new ArrayList<SoapUITestCaseStruct>();

	public String getApiName() {
		return apiName;
	}

	public void setApiName(String apiName) {
		this.apiName = apiName;
	}

	public List<SoapUITestCaseStruct> getTestCases() {
		return testCases;
	}

	public void setTestCases(List<SoapUITestCaseStruct> testCases) {
		this.testCases = testCases;
	}

	public String getMicroServiceName() {
		return microServiceName;
	}

	public void setMicroServiceName(String microServiceName) {
		this.microServiceName = microServiceName;
	}

	public void addTestCase(SoapUITestCaseStruct testCase){
		testCases.add(testCase);
	}
}
