package soapui.test.automation.service;

import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.util.List;

import org.apache.xmlbeans.XmlObject;

import com.eviware.soapui.SoapUI;
import com.eviware.soapui.StandaloneSoapUICore;
import com.eviware.soapui.impl.support.AbstractHttpRequest;
import com.eviware.soapui.impl.wsdl.WsdlProject;
import com.eviware.soapui.impl.wsdl.WsdlProjectFactory;
import com.eviware.soapui.impl.wsdl.WsdlTestSuite;
import com.eviware.soapui.impl.wsdl.testcase.WsdlTestCase;
import com.eviware.soapui.impl.wsdl.teststeps.HttpTestRequestStep;
import com.eviware.soapui.impl.wsdl.teststeps.WsdlTestStep;
import com.eviware.soapui.impl.wsdl.teststeps.assertions.TestAssertionRegistry;
import com.eviware.soapui.impl.wsdl.teststeps.registry.HttpRequestStepFactory;
import com.eviware.soapui.model.testsuite.TestAssertion;
import com.eviware.soapui.security.assertion.ValidHttpStatusCodesAssertion;
import com.eviware.soapui.support.types.StringToStringMap;

import soapui.test.automation.bean.SoapUITestCaseStruct;
import soapui.test.automation.bean.SoapUITestStepStruct;
import soapui.test.automation.bean.SoapUITestSuiteStruct;
import soapui.test.automation.constant.CommonConstants;
import soapui.test.automation.utils.CommonUtilities;
import soapui.test.automation.utils.TestCaseParser;

public class SoapUITestCaseCreator {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		try {
			SoapUITestCaseCreator instance = new SoapUITestCaseCreator();
			instance.createSoapUIProjects(args[0]);
		} catch (Throwable exp) {
			exp.printStackTrace();
		} finally {
			System.exit(0);
		}
	}

	private void createSoapUIProjects(String testPlanPath) throws Exception {
		File srcDir = new File(testPlanPath);
		System.out.println("path for test plan: " + testPlanPath);
		String[] testPlans = srcDir.list();

		for (String csvFile : testPlans) {
			if (!csvFile.toUpperCase().endsWith(CommonConstants.CSV_FILE_EXTENSION)) {
				continue;
			}

			createSoapUIProject(testPlanPath + File.separator + csvFile, getMicroserviceName(csvFile));
			System.out.println("Created test cases for: " + csvFile);
		}
	}

	private String getMicroserviceName(String testPlanName) {
		return testPlanName.substring(0,
				testPlanName.toUpperCase().lastIndexOf(CommonConstants.TESTPLAN_FILE_EXTENSION));
	}

	private void createSoapUIProject(String testPlan, String microServiceName) throws Exception {

		// read the test cases
		TestCaseParser parser = new TestCaseParser();
		List<SoapUITestSuiteStruct> testSuites = parser.readTestCases(testPlan);
		SoapUI.setSoapUICore(new StandaloneSoapUICore(true));

		File outputDir = new File(testPlan + "/../../soapui-projects");
		System.out.println("outputDir: " + outputDir + " microServiceName: " + microServiceName);
		if (!outputDir.exists() || !outputDir.isDirectory()) {
			System.out.println("Creating output directory");
			outputDir.mkdirs();
		}

		// create a project and add all of the functional test to this
		// project
		WsdlProjectFactory projectFactory = new WsdlProjectFactory();
		WsdlProject soapUIProject = projectFactory.createNew();
		soapUIProject.setName(microServiceName);

		// create File
		File projectFile = new File(outputDir.getPath() + "/" + microServiceName + "-soapui-project.xml");

		// add the test cases
		for (SoapUITestSuiteStruct ts : testSuites) {
			// get the suite if already exists in new project
			WsdlTestSuite soapuiTS = soapUIProject.getTestSuiteByName(ts.getApiName());
			if (soapuiTS == null) {
				soapuiTS = soapUIProject.addNewTestSuite(ts.getApiName());
				soapuiTS.setName(ts.getApiName());
			}

			// get the test cases and add
			addTestCases(ts, soapuiTS);

		}

		System.out.println("PROJECT CREATED... SAVING NOW...");
		soapUIProject.saveIn(projectFile);
		soapUIProject.release();
	}

	private void addTestCases(SoapUITestSuiteStruct ts, WsdlTestSuite soapuiTS) throws Exception {
		List<SoapUITestCaseStruct> testCaseList = ts.getTestCases();
		System.out.println("Inside addTestCases()...");
		for (SoapUITestCaseStruct tc : testCaseList) {
			// get the suite if already exists in new project
			WsdlTestCase soapuTC = soapuiTS.getTestCaseByName(tc.getTestCaseId());
			if (soapuTC == null) {
				soapuTC = soapuiTS.addNewTestCase(tc.getTestCaseId());
			}

			addTestSteps(tc, soapuTC);
		}
	}

	private void addTestSteps(SoapUITestCaseStruct tc, WsdlTestCase soapuTC) throws Exception {
		List<SoapUITestStepStruct> testSteps = tc.getTestSteps();
		System.out.println("Inside addTestSteps()...");
		for (SoapUITestStepStruct tStep : testSteps) {

			String completeURL = CommonConstants.PROJECT_ENDPOINT_KEY
					+ CommonUtilities.replacePathParams(tStep.getUrl()) + getRequestParamsMap(tStep.getRequestParams());
			// add http test step
			WsdlTestStep testStep = soapuTC.addTestStep(HttpRequestStepFactory.HTTPREQUEST_TYPE,
					tStep.getTestStep().substring(0, tStep.getTestStep().indexOf(CommonConstants.COLON)),
					getRequestParamsMap(tStep.getRequestParams()), tStep.getHttpMethod());
			HttpTestRequestStep httpTestStep = (HttpTestRequestStep) testStep;
			AbstractHttpRequest<?> httpRequest = httpTestStep.getHttpRequest();
			httpRequest.setRequestHeaders(getHeadersMap(tStep.getHeaders()));
			// Set end point
			httpRequest.setEndpoint(completeURL);
			addBasicAuth(tStep, httpRequest);
			// set Request body
			httpRequest.setRequestContent(tStep.getRequestBody());
			// add http status code assertion
			addValidHttpStatusCodeAssertion(tStep, httpTestStep);

		}
	}

	private void addBasicAuth(SoapUITestStepStruct tStep, AbstractHttpRequest<?> httpRequest) throws Exception {

		// get the method according to SOAP-UI version
		// in ready API 1.4.1 method is setAuthProfile()
		// in SOAP-UI pro 5.1.2 method is addBasicAuthenticationProfile()
		// if (true) {
		// load the sample test step from source project and import the
		// setting.
		String srcProjectPath = System.getProperty("SourceProjectPath", "./SourceTemplateProject-soapui-project.xml");
		WsdlProject sourcePro = new WsdlProject(srcProjectPath);
		httpRequest.getConfig().setCredentials(
				((HttpTestRequestStep) sourcePro.getTestSuiteByName("Sample").getTestCaseByName("Sample")
						.getTestStepByName("Sample")).getHttpRequest().getConfig().getCredentials());
		httpRequest.setUsername(tStep.getAuth().getUserName());
		httpRequest.setPassword(tStep.getAuth().getPassword());

		// } else {
		// httpRequest
		// .getConfig()
		// .addNewCredentials()
		// .setAuthType(
		// CredentialsConfig.AuthType.Enum.forString(tStep
		// .getAuth().getAuthType()));
		//
		// Method setAuthProfile = null;
		// try {
		// setAuthProfile = httpRequest.getClass().getSuperclass()
		// .getSuperclass()
		// .getDeclaredMethod("setAuthProfile", String.class);
		// } catch (Throwable exp) {
		// // ignore
		// System.out
		// .println("Using another method addBasicAuthenticationProfile():");
		// setAuthProfile = httpRequest
		// .getClass()
		// .getSuperclass()
		// .getSuperclass()
		// .getDeclaredMethod("addBasicAuthenticationProfile",
		// String.class);
		// }
		//
		// if (setAuthProfile == null) {
		// throw new RuntimeException(
		// "Method not found for setting basic authentication");
		// }
		// setAuthProfile.invoke(httpRequest, tStep.getAuth().getAuthType());
		// // httpRequest
		// // .addBasicAuthenticationProfile(tStep.getAuth().getAuthType());
		//
		// Method setSelectedAuthProfile = null;
		// try {
		// setSelectedAuthProfile = httpRequest
		// .getClass()
		// .getSuperclass()
		// .getSuperclass()
		// .getDeclaredMethod("setSelectedAuthProfile",
		// String.class);
		// setSelectedAuthProfile.invoke(httpRequest, tStep.getAuth()
		// .getAuthType());
		// } catch (Throwable exp) {
		// // ignore
		// System.out
		// .println("Using another method addBasicAuthenticationProfile():");
		// setSelectedAuthProfile = httpRequest
		// .getClass()
		// .getSuperclass()
		// .getSuperclass()
		// .getDeclaredMethod("setSelectedAuthProfileAndAuthType",
		// String.class,
		// CredentialsConfig.AuthType.Enum.class);
		// setSelectedAuthProfile.invoke(httpRequest, tStep.getAuth()
		// .getAuthType(),
		// CredentialsConfig.AuthType.GLOBAL_HTTP_SETTINGS);
		// }

		// httpRequest
		// .setSelectedAuthProfileAndAuthType(tStep.getAuth()
		// .getAuthType(),
		// CredentialsConfig.AuthType.GLOBAL_HTTP_SETTINGS);
		// }
	}

	private void addValidHttpStatusCodeAssertion(SoapUITestStepStruct tStep, HttpTestRequestStep httpTestStep)
			throws NoSuchFieldException, IllegalAccessException, NoSuchMethodException, InvocationTargetException {
		TestAssertionRegistry testAss = TestAssertionRegistry.getInstance();
		testAss.addAssertion(new ValidHttpStatusCodesAssertion.Factory());

		TestAssertion assertion = httpTestStep.addAssertion(ValidHttpStatusCodesAssertion.ID);
		java.lang.reflect.Field statusAssertionCodesField = assertion.getClass()
				.getDeclaredField(CommonConstants.HTTP_STATUS_CODES_KEY);
		// Make the private field accessible
		statusAssertionCodesField.setAccessible(true);
		statusAssertionCodesField.set(assertion, tStep.getHttpResponseCode());
		java.lang.reflect.Method statusAssertionCreateConfigurationMethod = assertion.getClass()
				.getDeclaredMethod(CommonConstants.CREATE_CONFIGURATION_METHOD_NAME);
		// Make the protected method accessible
		statusAssertionCreateConfigurationMethod.setAccessible(true);

		// Create the configuration and set it on the assertion.
		XmlObject assertionConfiguration = (XmlObject) statusAssertionCreateConfigurationMethod.invoke(assertion);
		((ValidHttpStatusCodesAssertion) assertion).setConfiguration(assertionConfiguration);
	}

	private StringToStringMap getHeadersMap(String[] headers) {
		StringToStringMap headersMap = new StringToStringMap();
		for (String header : headers) {
			if (header == null || header.trim().length() == 0) {
				continue;
			}
			String[] keyValue = header.split("=");
			String key = keyValue[0];
			String value = keyValue[0];
			if (keyValue.length == 2) {
				value = keyValue[1];
			}
			headersMap.put(key, CommonConstants.PROJECT_PROP + value + "}");
		}
		return headersMap;
	}

	private String getRequestParamsMap(String[] reqParams) {
		if (reqParams == null || reqParams.length == 0) {
			return "";
		}
		StringBuilder reqParamsStr = new StringBuilder();
		int i = 0;
		for (String param : reqParams) {
			if (param == null || param.trim().length() == 0) {
				continue;
			}

			// add separator to query parameter
			if (i != 0) {
				reqParamsStr.append("&");
			} else {
				reqParamsStr.append("?");
			}

			String[] keyValue = param.split("=");
			String key = keyValue[0];
			String value = keyValue[0];
			if (keyValue.length == 2) {
				value = keyValue[1];
			}
			reqParamsStr.append(key + "=" + CommonConstants.PROJECT_PROP + value + "}");
			i++;
		}
		return reqParamsStr.toString();
	}

}
