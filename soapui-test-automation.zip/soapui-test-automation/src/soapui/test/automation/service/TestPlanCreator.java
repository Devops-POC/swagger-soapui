package soapui.test.automation.service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

import soapui.test.automation.bean.TestCaseCount;
import soapui.test.automation.bean.ms.MicroServiceInfo;
import soapui.test.automation.bean.ms.Parameter;
import soapui.test.automation.bean.ms.Response;
import soapui.test.automation.bean.ms.RestFullAPIInfo;
import soapui.test.automation.constant.CommonConstants;
import soapui.test.automation.constant.CommonConstants.ParameterType;
import soapui.test.automation.utils.CurlParser;
import soapui.test.automation.utils.SwaggerParser;

public class TestPlanCreator {

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		TestPlanCreator instance = new TestPlanCreator();
		// check the type of input
		if (args != null && args.length > 2) {
			if (args[1]
					.equalsIgnoreCase(CommonConstants.INPUT_TYPE_SWAGGERJSON)) {
				instance.createTestPlans(args[0]);
			} else if (args[1]
					.equalsIgnoreCase(CommonConstants.INPUT_TYPE_CURL)) {
				instance.createTestPlanFromCURL(args[0]);
			} else {
				throw new RuntimeException(
						"Invalid type of input documentation!");
			}
		}
		instance.createTestPlans(args[0]);

	}

	private void createTestPlanFromCURL(String curlCommandFile)
			throws Exception {
		BufferedReader reader = null;
		BufferedWriter writer = null;
		try {

			reader = new BufferedReader(new FileReader(curlCommandFile));
			String lineVal = "";
			while ((lineVal = reader.readLine()) != null) {
				// create a property to record all the parameters which can be
				// used
				// to
				// integrate the test data
				Properties prop = new Properties();
				RestFullAPIInfo api = CurlParser.getInstance()
						.getRestFullAPIForCurlParser(lineVal);
				String microServiceName = System.getProperty(
						CommonConstants.MICROSERVICENAME_KEY,
						CommonConstants.INPUT_TYPE_SWAGGERJSON);
				setAPIName(api);
				writer = createTestPlanFile(microServiceName, writer);
				TestCaseCount tcCount = new TestCaseCount();
				createTestPlan(api, microServiceName, writer, tcCount, prop);
				// save the properties in a file which can be used for test data
				// integration
				prop.store(
						new FileOutputStream(
								"./TestPlans/TestParamerts.properties"),
						"This property file can be used to integrate the test data, update the values for this property and use to execute the test.");

			}
		} finally {
			if (reader != null) {
				reader.close();
			}

			if (writer != null) {
				writer.close();
			}
		}
	}

	private void createTestPlans(String jsonsDirPath) throws Exception {
		File srcDir = new File(jsonsDirPath);
		String[] testPlans = srcDir.list();
		for (String jsonFile : testPlans) {
			if (!jsonFile.toUpperCase().endsWith(
					CommonConstants.JSON_FILE_EXTENSION)) {
				continue;
			}

			createTestPlan(jsonsDirPath + File.separator + jsonFile,
					getMicroserviceName(jsonFile));

		}
	}

	private void createTestPlan(String jsonFilePath, String microServiceName)
			throws Exception {

		// get the micro service details from JSON file
		SwaggerParser parser = SwaggerParser.getInstance();
		MicroServiceInfo microService = parser.getMicroService(jsonFilePath);
		List<RestFullAPIInfo> apis = microService.getApis();
		BufferedWriter writer = null;
		try {
			// create a property to record all the parameters which can be used
			// to
			// integrate the test data
			Properties prop = new Properties();

			// add endpoint property
			prop.setProperty("endpoint","");
			// create test plan csv file for this micro service
			writer = createTestPlanFile(microServiceName, writer);
			TestCaseCount tcCount = new TestCaseCount();
			for (RestFullAPIInfo api : apis) {
				// set API name
				setAPIName(api);
				createTestPlan(api, microServiceName, writer, tcCount, prop);
			}
			// save the properties in a file which can be used for test data
			// integration
			prop.store(
					new FileOutputStream("./TestPlans/TestParamFiles/"
							+ microServiceName.toUpperCase()
							+ "TestParamerts.properties"),
					"This property file can be used to integrate the test data, update the values for this property and use to execute the test.");

		} finally {
			if (writer != null) {
				writer.close();
			}
		}
	}

	private void setAPIName(RestFullAPIInfo api) {
		api.setName(getAPIName(api).toString());

	}

	private BufferedWriter createTestPlanFile(String microServiceName,
			BufferedWriter writer) throws Exception {
		String testPlanPath = "";
		File file = new File("./TestPlans");
		if (!file.exists()) {
			file.mkdirs();
		}

		// check for test param directory, if not exists create new one
		File fileTestParam = new File("./TestPlans/TestParamFiles");
		if (!fileTestParam.exists()) {
			fileTestParam.mkdirs();
		}

		// create a csv file with micro service name
		testPlanPath = file.getPath() + "/" + microServiceName.toUpperCase()
				+ CommonConstants.TESTPLAN_FILE_EXTENSION;
		writer = new BufferedWriter(new FileWriter(testPlanPath));
		writer.append(CommonConstants.TESTPLANCOLUMNHEADER);
		writer.newLine();
		return writer;
	}

	private void createTestPlan(RestFullAPIInfo api, String microserviceName,
			BufferedWriter writer, TestCaseCount tcCount, Properties prop)
			throws IOException {

		// start writing the test cases rows
		// create combination between parameters(headers,path,query) and
		// response code
		// add the positive test case
		addPositiveTestCase(writer, api, microserviceName,
				tcCount.increamentCount(), prop);
		// in case only positive test cases need to create then skip negative
		// test case creation
		if (!CommonConstants.ONLYPOSITIVE.equalsIgnoreCase(System
				.getProperty(CommonConstants.TEST_TYPE_KEY))) {
			for (Parameter param : api.getParameters()) {
				addNegativeTestCase(writer, api, microserviceName,
						tcCount.increamentCount(), param, prop);
			}
		}

	}

	private void addNegativeTestCase(BufferedWriter writer,
			RestFullAPIInfo api, String microserviceName, int tcCount,
			Parameter param, Properties prop) throws IOException {

		StringBuilder rowVal = new StringBuilder();
		rowVal.append(getTestCaseId(microserviceName, tcCount)).append(",");
		rowVal.append(getTestStepName(api, tcCount, false, param));
		rowVal.append(":").append("HTTP").append(",");
		rowVal.append(api.getName()).append(",");
		String uri = api.getBaseUri() + api.getUri();
		rowVal.append(getURLWithInvalidPathParam(uri, param, prop)).append(",");
		rowVal.append(api.getHttpMethod()).append(",");
		rowVal.append(getInvailParam(api, param, ParameterType.QUERY, prop))
				.append(",");
		rowVal.append("").append(",");
		rowVal.append(getInvailParam(api, param, ParameterType.HEADER, prop))
				.append(",");
		rowVal.append("Basic@test23:Testing123").append(",");
		rowVal.append(getDefaultResponseCode(api));
		writer.append(rowVal);
		writer.newLine();
	}

	private void addPositiveTestCase(BufferedWriter writer,
			RestFullAPIInfo api, String microserviceName, int tcCount,
			Properties prop) throws IOException {
		StringBuilder rowVal = new StringBuilder();
		rowVal.append(getTestCaseId(microserviceName, tcCount)).append(",");
		rowVal.append(getTestStepName(api, 1, true, null));
		rowVal.append(":").append("HTTP").append(",");
		rowVal.append(api.getName()).append(",");
		String uri = api.getBaseUri() + api.getUri();
		rowVal.append(getURLWithInvalidPathParam(uri, null, prop)).append(",");
		rowVal.append(api.getHttpMethod()).append(",");
		rowVal.append(getInvailParam(api, null, ParameterType.QUERY, prop))
				.append(",");
		rowVal.append("").append(",");
		rowVal.append(getInvailParam(api, null, ParameterType.HEADER, prop))
				.append(",");
		rowVal.append("Basic@test23:Testing123").append(",");
		rowVal.append(getDefaultResponseCode(api));
		writer.append(rowVal);
		writer.newLine();
	}

	private String getURLWithInvalidPathParam(String uri, Parameter param,
			Properties prop) {
		if (param != null
				&& ParameterType.PATH.toString()
						.equalsIgnoreCase(param.getIn())) {
			String paramKey = param.getName() + "Invalid";
			// add the parameter key to prop
			prop.setProperty(paramKey, "");
			prop.setProperty(param.getName(), "");
			return uri.replace(param.getName(), paramKey);
		}
		return uri;
	}

	private String getDefaultResponseCode(RestFullAPIInfo api) {
		Map<String, Response> resMap = api.getResponses();
		Set<Entry<String, Response>> entrySet = resMap.entrySet();
		Iterator<Entry<String, Response>> ite = entrySet.iterator();
		String code = "200";
		while (ite.hasNext()) {
			Entry<String, Response> entry = ite.next();
			System.out.println(entry.getKey() + ": "
					+ entry.getValue().toString());
			code = entry.getKey();
			break;
		}
		return code;
	}

	private String getInvailParam(RestFullAPIInfo api, Parameter paramTo,
			ParameterType type, Properties prop) {
		int i = 0;
		StringBuilder buff = new StringBuilder();
		for (Parameter param : api.getParameters()) {

			if (!type.toString().equalsIgnoreCase(param.getIn())) {
				continue;
			}
			if (i != 0) {
				buff.append(";");
			}
			// set the parameter key
			prop.setProperty(param.getName(), "");

			buff.append(param.getName());
			if (paramTo != null && paramTo.getName().equals(param.getName())
					&& paramTo.getIn().equals(param.getIn())) {
				if (ParameterType.QUERY.equals(type)
						|| ParameterType.HEADER.equals(type)) {
					buff.append("=" + param.getName() + "Invalid");
					// set the parameter key
					prop.setProperty(param.getName() + "Invalid", "");
				} else {
					buff.append("Invalid");
				}
			}

			i++;
		}
		return buff.toString();
	}

	private String getTestStepName(RestFullAPIInfo api, int i,
			boolean isPositive, Parameter param) {
		StringBuilder buff = getAPIName(api);
		if (isPositive) {
			// this means this is the first case and here we should add all
			// positive values and test steps name should be valid
			buff.append("Valid");

		} else {
			buff.append("_Invalid")
					.append(param.getName().substring(0, 1).toUpperCase())
					.append(param.getName().substring(1));
		}

		return buff.toString();
	}

	private StringBuilder getAPIName(RestFullAPIInfo api) {
		String nameToUse = (api.getName() == null || api.getName().trim()
				.length() == 0) ? api.getUri() : api.getName();
		String[] pathsVars = nameToUse.split("/");
		StringBuilder buff = new StringBuilder();
		int index = 0;
		for (String token : pathsVars) {
			if (index++ == 0) {
				buff.append(token);
			} else {
				buff.append(token.substring(0, 1).toUpperCase()
						+ token.substring(1).toLowerCase());
			}
		}
		// buff = new
		// StringBuilder(buff.toString().replaceAll("[^\\p{L}\\p{Z}]",
		// ""));
		return buff;
	}

	private String getTestCaseId(String microserviceName, int tcCount) {
		return microserviceName.toUpperCase() + "_TC"
				+ String.format("%03d", tcCount);
	}

	private String getMicroserviceName(String jsonFile) {
		return jsonFile.substring(
				0,
				jsonFile.toUpperCase().lastIndexOf(
						CommonConstants.JSON_FILE_EXTENSION));
	}

}
