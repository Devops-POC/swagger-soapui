package soapui.test.automation.utils;

import soapui.test.automation.constant.CommonConstants;

public class CommonUtilities {

	public static String replacePathParams(String requestUrl) {

		StringBuilder finalRequestUrl = new StringBuilder();
		for (int i = 0; i < requestUrl.length(); i++) {
			char ch = requestUrl.charAt(i);
			if (ch == '{') {
				finalRequestUrl.append(CommonConstants.PROJECT_PROP);
			} else {
				finalRequestUrl.append(ch);
			}
		}

		return finalRequestUrl.toString();
	}

	public static void main(String[] args) {
		System.out
				.println(replacePathParams("/test/{version}/{abc}/n?test=123"));
	}
}
