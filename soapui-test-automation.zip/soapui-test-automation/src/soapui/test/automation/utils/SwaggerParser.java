package soapui.test.automation.utils;

import io.swagger.models.HttpMethod;
import io.swagger.models.Operation;
import io.swagger.models.Path;
import io.swagger.models.Swagger;
import io.swagger.models.parameters.Parameter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import soapui.test.automation.bean.ms.MicroServiceInfo;
import soapui.test.automation.bean.ms.Response;
import soapui.test.automation.bean.ms.RestFullAPIInfo;

public class SwaggerParser {

	private static SwaggerParser instance;
	private static Long lock = -1l;

	private SwaggerParser() {
		if (instance != null) {
			throw new RuntimeException(
					"Instance already created for this singleton class!");
		}
	}

	public static SwaggerParser getInstance() {
		if (instance != null) {
			return instance;
		}
		synchronized (lock) {
			if (instance == null) {
				instance = new SwaggerParser();
			}
		}
		return instance;
	}

	public MicroServiceInfo getMicroService(String jsonPath) {

		MicroServiceInfo ms = new MicroServiceInfo();
		io.swagger.parser.SwaggerParser parser = new io.swagger.parser.SwaggerParser();
		Swagger swagger = parser.read(jsonPath);
		// set the basic information about the micro service
		ms.setBasePath(swagger.getBasePath());
		ms.setConsumes(swagger.getConsumes());
		ms.setHost(swagger.getHost());
		ms.setProduces(swagger.getProduces());

		// create REST API using swagger information
		// iterate through each of the path and add all of the different
		// operations as one API
		Map<String, Path> paths = swagger.getPaths();
		Set<Entry<String, Path>> entriesSet = paths.entrySet();
		Iterator<Entry<String, Path>> iterator = entriesSet.iterator();
		while (iterator.hasNext()) {
			Entry<String, Path> entry = iterator.next();
			String apiUri = entry.getKey();
			Map<HttpMethod, Operation> supportedOpts = entry.getValue()
					.getOperationMap();
			Set<Entry<HttpMethod, Operation>> entriesSetOpts = supportedOpts
					.entrySet();
			Iterator<Entry<HttpMethod, Operation>> iteratorOpts = entriesSetOpts
					.iterator();
			while (iteratorOpts.hasNext()) {
				Entry<HttpMethod, Operation> optEntry = iteratorOpts.next();
				HttpMethod method = optEntry.getKey();
				Operation opt = optEntry.getValue();
				RestFullAPIInfo api = new RestFullAPIInfo();
				api.setUri(apiUri);
				api.setBaseUri(ms.getBasePath());
				api.setConsumes(opt.getConsumes());
				api.setDescription(opt.getDescription());
				api.setName(opt.getOperationId());
				api.setParameters(createParameters(opt.getParameters()));
				api.setProduces(opt.getProduces());
				api.setResponses(createResponses(opt.getResponses()));
				api.setHttpMethod(method.name());
				updateParamsToRespectiveCat(api);
				ms.addApi(api);
			}
		}

		return ms;
	}

	private Map<String, Response> createResponses(
			Map<String, io.swagger.models.Response> responses) {
		Map<String, Response> responseOut = new HashMap<String, Response>();
		if (responses == null) {
			return responseOut;
		}
		Set<Entry<String, io.swagger.models.Response>> entrySet = responses
				.entrySet();
		Iterator<Entry<String, io.swagger.models.Response>> ite = entrySet
				.iterator();

		while (ite.hasNext()) {
			Entry<String, io.swagger.models.Response> entry = ite.next();
			Response newRes = new Response();
			newRes.setStatusCode(entry.getKey());
			responseOut.put(entry.getKey(), newRes);
		}
		return responseOut;
	}

	private List<soapui.test.automation.bean.ms.Parameter> createParameters(
			List<Parameter> parameters) {
		List<soapui.test.automation.bean.ms.Parameter> params = new ArrayList<soapui.test.automation.bean.ms.Parameter>();
		if (parameters == null) {
			return params;
		}
		for (Parameter srcParam : parameters) {
			soapui.test.automation.bean.ms.Parameter newSoapUIParam = new soapui.test.automation.bean.ms.Parameter();
			newSoapUIParam.setName(srcParam.getName());
			newSoapUIParam.setIn(srcParam.getIn());
			params.add(newSoapUIParam);
		}
		return params;
	}

	private void updateParamsToRespectiveCat(RestFullAPIInfo api) {
		// set the header if any
		for (soapui.test.automation.bean.ms.Parameter param : api
				.getParameters()) {
			if ("header".equalsIgnoreCase(param.getIn())) {
				api.addHeader(param.getName());
			}
			if ("query".equalsIgnoreCase(param.getIn())) {
				api.addRequestParam(param.getName());
			}
			if ("path".equalsIgnoreCase(param.getIn())) {
				api.addPathVariable(param.getName());
			}
		}
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		// ObjectMapper m = new ObjectMapper();
		// JsonNode rootNode = m.readTree(new File(args[0]));
		// JsonNode pathsNode = rootNode.path("paths");
		// Iterator<Entry<String, JsonNode>> paths = pathsNode.fields();
		// while (paths.hasNext()) {
		// Entry<String, JsonNode> entry = paths.next();
		//
		// System.out.println(entry.getKey() + ":"
		// + entry.getValue().textValue());
		// Iterator<Entry<String, JsonNode>> ele = entry.getValue().fields();
		// while (ele.hasNext()) {
		// Entry<String, JsonNode> methods = ele.next();
		//
		// System.out.println(methods.getKey() + ":"
		// + methods.getValue().toString());
		// Iterator<Entry<String, JsonNode>> methodsAttrs = methods
		// .getValue().fields();
		// while (methodsAttrs.hasNext()) {
		// Entry<String, JsonNode> attributes = methodsAttrs.next();
		// System.out.println(attributes.getKey() + ": "
		// + attributes.getValue().toString());
		// }
		// }
		// }
		io.swagger.parser.SwaggerParser parser = new io.swagger.parser.SwaggerParser();
		Swagger swagger = parser.read(args[0]);
		System.out.println(swagger.getBasePath());
		System.out.println(swagger.getHost());
		System.out.println(swagger.getPaths());
		Map<String, Path> paths = swagger.getPaths();
		Set<String> keys = paths.keySet();
		Iterator<String> it = keys.iterator();
		while (it.hasNext()) {
			String key = it.next();
			System.out.println(key + ": ");
			System.out.println(paths.get(key));
			Path path = paths.get(key);
			List<Operation> operations = path.getOperations();
			for (Operation opt : operations) {
				System.out.println("name: " + opt.getOperationId());
				System.out.println("Dsc: " + opt.getDescription());
				System.out.println("Consumes: " + opt.getConsumes());
				System.out.println("Produces: " + opt.getProduces());
				System.out.println("Responses: " + opt.getResponses());
				System.out.println("Parameters: " + opt.getParameters());
			}
		}
	}
}
