package soapui.test.automation.utils;

import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Iterator;
import java.util.Scanner;

import soapui.test.automation.bean.ms.RestFullAPIInfo;

public class CurlParser {

	private static CurlParser instance;
	private static Long lock = -1l;

	private CurlParser() {
		if (instance != null) {
			throw new RuntimeException(
					"Instance already created for this singleton class!");
		}
	}

	public static CurlParser getInstance() {
		if (instance != null) {
			return instance;
		}
		synchronized (lock) {
			if (instance == null) {
				instance = new CurlParser();
			}
		}
		return instance;
	}

	public RestFullAPIInfo getRestFullAPIForCurlParser(String curlCommand)
			throws MalformedURLException, URISyntaxException {

		RestFullAPIInfo api = new RestFullAPIInfo();
		String string = curlCommand;
		string = string.replaceAll("\\s+", " ").trim();
		if (string.contains(" ")) {
			String[] result = string.split(" ");
			for (int x = 0; x < result.length; x++) {
				System.out.println(result[x]);
				if (result[x].startsWith("http")
						|| result[x].startsWith("'http")
						|| result[x].startsWith("/")) {
					result[x] = result[x].replace("'", "");
					URL url = new URL(result[x]);

					api.setUri(url.toURI().toString());

					if (url.toString().contains("?")) {
						String requestParams = url.toString().substring(
								url.toString().lastIndexOf("?") + 1);
						String[] requestParams_split = requestParams.split("&");
						for (int y = 0; y < requestParams_split.length; y++) {
							api.addRequestParam(requestParams_split[y]);
						}
					}

					String pathVariables = url.toString().substring(0,
							url.toString().indexOf('?'));
					String[] pathVariables_split = pathVariables.split("/");
					System.out.println("************************************");
					for (int z = 0; z < pathVariables_split.length; z++) {
						if (z != 0 && z != 1 && z != 2
								&& pathVariables_split[z].matches("[a-zA-Z]+")) {
							System.out.println(pathVariables_split[z]);
						} else if (z != 0 && z != 1 && z != 2) {
							api.addPathVariable(pathVariables_split[z]);
						}
					}
					System.out.println("************************************");

				} else if (result[x].equals("-X")
						|| result[x].equalsIgnoreCase("--request")) {
					api.setHttpMethod(result[x + 1]);
				} else if (result[x].equalsIgnoreCase("-h")
						|| result[x].equalsIgnoreCase("--header")) {

					for (int y = x + 1; y < result.length; y++) {
						if (result[y].startsWith("'")
								|| result[y].startsWith("\"")) {
							if (result[y].endsWith(":")) {
								api.addHeader(result[y].concat(result[y + 1]));
							} else if (result[y].endsWith("'")
									|| result[y].endsWith("\"")) {
								api.addHeader(result[y]);
							}

						} else if (result[y].startsWith("-")) {
							break;
						}
					}

				} else if (result[x].equalsIgnoreCase("-d")
						|| result[x].equalsIgnoreCase("--data")) {

					for (int y = x + 1; y < result.length; y++) {
						if (result[y].startsWith("'")) {
							if (result[y].endsWith("'")) {
								api.setData(result[y]);
							} else if (result[y + 1].endsWith("'")) {
								api.setData(result[y].concat(result[y + 1]));
							}

						} else if (result[y].startsWith("-")) {
							break;
						}
					}

				} else if (result[x].equalsIgnoreCase("-u")
						|| result[x].equalsIgnoreCase("--user")) {

					if (result[x + 1].contains(":")) {
						String[] creds = result[x + 1].split(":");

						System.out.println("user: " + creds[0]);
						System.out.println("Pass:" + creds[1]);

					}

				}

			}
		}

		else {
			throw new IllegalArgumentException("Wrong cURL command.");
		}
		return api;

		/*
		 * URL myURL = new URL(serviceURL); HttpURLConnection myURLConnection =
		 * (HttpURLConnection)myURL.openConnection();
		 * api.setHttpMethod(myURLConnection.getRequestMethod());;
		 * myURLConnection.setRequestMethod("PUT");
		 * myURLConnection.setRequestProperty("X-Parse-Application-Id", "");
		 * myURLConnection.setRequestProperty("X-Parse-REST-API-Key", "");
		 * myURLConnection.setRequestProperty("Content-Type",
		 * "application/json"); myURLConnection.setUseCaches(false);
		 * myURLConnection.setDoInput(true); myURLConnection.connect();
		 * 
		 * JSONObject jsonParam = new JSONObject(); jsonParam.put("score",
		 * "73453");
		 * 
		 * OutputStream os = myURLConnection.getOutputStream();
		 * os.write(URLEncoder.encode(jsonParam.toString(),"UTF-8"));
		 * os.close();
		 * 
		 * 
		 * //io.swagger.parser.SwaggerParser parser = new
		 * io.swagger.parser.SwaggerParser(); //Swagger swagger =
		 * parser.read(jsonPath); // set the basic information about the micro
		 * service //ms.setBasePath(swagger.getBasePath());
		 * //ms.setConsumes(swagger.getConsumes());
		 * //ms.setHost(swagger.getHost());
		 * //ms.setProduces(swagger.getProduces());
		 * 
		 * // Create REST API using cURL information // iterate through each of
		 * the path and add all of the different // operations as one API
		 * Map<String, Path> paths = swagger.getPaths(); Set<Entry<String,
		 * Path>> entriesSet = paths.entrySet(); Iterator<Entry<String, Path>>
		 * iterator = entriesSet.iterator(); while (iterator.hasNext()) {
		 * Entry<String, Path> entry = iterator.next(); String apiUri =
		 * entry.getKey(); Map<HttpMethod, Operation> supportedOpts =
		 * entry.getValue() .getOperationMap(); Set<Entry<HttpMethod,
		 * Operation>> entriesSetOpts = supportedOpts .entrySet();
		 * Iterator<Entry<HttpMethod, Operation>> iteratorOpts = entriesSetOpts
		 * .iterator(); while (iteratorOpts.hasNext()) { Entry<HttpMethod,
		 * Operation> optEntry = iteratorOpts.next(); HttpMethod method =
		 * optEntry.getKey(); Operation opt = optEntry.getValue();
		 * RestFullAPIInfo api = new RestFullAPIInfo();
		 * api.setUri(ms.getBasePath() == null ? apiUri : ms.getBasePath() +
		 * apiUri); api.setConsumes(opt.getConsumes());
		 * api.setDescription(opt.getDescription());
		 * api.setName(opt.getOperationId());
		 * api.setParameters(opt.getParameters());
		 * api.setProduces(opt.getProduces());
		 * api.setResponses(opt.getResponses());
		 * api.setHttpMethod(method.name()); updateParamsToRespectiveCat(api);
		 * ms.addApi(api); } }
		 * 
		 * retur
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * +-n ms;
		 */
	}

	/*
	 * private void updateParamsToRespectiveCat(RestFullAPIInfo api) { // set
	 * the header if any for (Parameter param : api.getParameters()) { if
	 * ("header".equalsIgnoreCase(param.getIn())) {
	 * api.addHeader(param.getName()); } if
	 * ("query".equalsIgnoreCase(param.getIn())) {
	 * api.addRequestParam(param.getName()); } if
	 * ("path".equalsIgnoreCase(param.getIn())) {
	 * api.addPathVariable(param.getName()); } } }
	 */

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {

		@SuppressWarnings("resource")
		Scanner curl = new Scanner(System.in);
		String input = curl.nextLine();

		RestFullAPIInfo curlParser = new CurlParser()
				.getRestFullAPIForCurlParser(input);
		System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
		System.out.println(curlParser.getUri());
		System.out.println(curlParser.getHttpMethod());
		System.out.println(curlParser.getData());
		Iterator<String> iterator = curlParser.getHeaders().iterator();
		Iterator<String> iterator_requestParams = curlParser.getRequestParams()
				.iterator();
		Iterator<String> iterator_pathVariables = curlParser.getPathVariables()
				.iterator();

		while (iterator.hasNext()) {
			System.out.println(iterator.next());

		}

		while (iterator_requestParams.hasNext()) {
			System.out.println(iterator_requestParams.next());

		}
		while (iterator_pathVariables.hasNext()) {
			System.out.println(iterator_pathVariables.next());

		}

		// ObjectMapper m = new ObjectMapper();
		// JsonNode rootNode = m.readTree(new File(args[0]));
		// JsonNode pathsNode = rootNode.path("paths");
		// Iterator<Entry<String, JsonNode>> paths = pathsNode.fields();
		// while (paths.hasNext()) {
		// Entry<String, JsonNode> entry = paths.next();
		//
		// System.out.println(entry.getKey() + ":"
		// + entry.getValue().textValue());
		// Iterator<Entry<String, JsonNode>> ele = entry.getValue().fields();
		// while (ele.hasNext()) {
		// Entry<String, JsonNode> methods = ele.next();
		//
		// System.out.println(methods.getKey() + ":"
		// + methods.getValue().toString());
		// Iterator<Entry<String, JsonNode>> methodsAttrs = methods
		// .getValue().fields();
		// while (methodsAttrs.hasNext()) {
		// Entry<String, JsonNode> attributes = methodsAttrs.next();
		// System.out.println(attributes.getKey() + ": "
		// + attributes.getValue().toString());
		// }
		// }
		// }
		// io.swagger.parser.SwaggerParser parser = new
		// io.swagger.parser.SwaggerParser();
		// Swagger swagger = parser.read(args[0]);
		// System.out.println(swagger.getBasePath());
		// System.out.println(swagger.getHost());
		// System.out.println(swagger.getPaths());
		// Map<String, Path> paths = swagger.getPaths();
		// Set<String> keys = paths.keySet();
		// Iterator<String> it = keys.iterator();
		/*
		 * while (it.hasNext()) { String key = it.next(); System.out.println(key
		 * + ": "); System.out.println(paths.get(key)); Path path =
		 * paths.get(key); List<Operation> operations = path.getOperations();
		 * for (Operation opt : operations) { System.out.println("name: " +
		 * opt.getOperationId()); System.out.println("Dsc: " +
		 * opt.getDescription()); System.out.println("Consumes: " +
		 * opt.getConsumes()); System.out.println("Produces: " +
		 * opt.getProduces()); System.out.println("Responses: " +
		 * opt.getResponses()); System.out.println("Parameters: " +
		 * opt.getParameters()); }
		 */
	}
}
