package soapui.test.automation.utils;

import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import au.com.bytecode.opencsv.CSVReader;

import soapui.test.automation.bean.AuthBean;
import soapui.test.automation.bean.SoapUITestCaseStruct;
import soapui.test.automation.bean.SoapUITestStepStruct;
import soapui.test.automation.bean.SoapUITestSuiteStruct;
import soapui.test.automation.constant.CommonConstants;

public class TestCaseParser {

	public List<SoapUITestSuiteStruct> readTestCases(String testPlanFilePath)
			throws Exception {
		List<SoapUITestSuiteStruct> testCases = new ArrayList<SoapUITestSuiteStruct>();

		// read line by line and construct test suite objects
		CSVReader reader = null;
		try {
			reader = new CSVReader(new FileReader(testPlanFilePath));
			String[] nextLine;

			Map<String, SoapUITestCaseStruct> testCasesMap = new HashMap<String, SoapUITestCaseStruct>();
			Map<String, SoapUITestSuiteStruct> testSuiteMap = new HashMap<String, SoapUITestSuiteStruct>();

			// skip the column name row(first row)
			reader.readNext();
			while ((nextLine = reader.readNext()) != null) {
				String authStr = nextLine[CommonConstants.testPlanColIndex
						.get(CommonConstants.AUTH)].trim();
				AuthBean auth = new AuthBean();
				if (authStr != null && authStr.length() != 0) {
					auth.setAuthType(authStr.substring(0, authStr.indexOf('@')));
					auth.setUserName(authStr.substring(
							(authStr.indexOf('@') + 1), authStr.indexOf(':')));
					auth.setPassword(authStr.substring(
							(authStr.indexOf(':') + 1), authStr.length()));
				}
				SoapUITestStepStruct testStep = new SoapUITestStepStruct(
						nextLine[CommonConstants.testPlanColIndex
								.get(CommonConstants.TESTCASE_ID)],
						nextLine[CommonConstants.testPlanColIndex
								.get(CommonConstants.TEST_STEP)],
						nextLine[CommonConstants.testPlanColIndex
								.get(CommonConstants.URL)],
						nextLine[CommonConstants.testPlanColIndex
								.get(CommonConstants.HTTP_METHOD)],
						nextLine[CommonConstants.testPlanColIndex
								.get(CommonConstants.REQUEST_PARAMETERS)]
								.split(";"),
						nextLine[CommonConstants.testPlanColIndex
								.get(CommonConstants.REQUEST_BODY)],
						nextLine[CommonConstants.testPlanColIndex
								.get(CommonConstants.HEADERS)].split(";"),
						auth, nextLine[CommonConstants.testPlanColIndex
								.get(CommonConstants.HTTP_RESPONSE_CODE)]);

				// check if test case already exists then just add the test step
				SoapUITestCaseStruct testCase = testCasesMap.get(testStep
						.getTestCaseId());
				if (testCase == null) {
					// create a test case object
					testCase = new SoapUITestCaseStruct();
					testCasesMap.put(testStep.getTestCaseId(), testCase);
				}
				testCase.setTestCaseId(nextLine[CommonConstants.testPlanColIndex
						.get(CommonConstants.TESTCASE_ID)]);
				testCase.setApiName(nextLine[CommonConstants.testPlanColIndex
						.get(CommonConstants.API)]);
				testCase.addTestStep(testStep);
				System.out.println("Test Step: " + testStep);
				// add the test case to test suite if already exists otherwise
				// create new one
				SoapUITestSuiteStruct testSuite = testSuiteMap.get(testCase
						.getApiName());
				if (testSuite == null) {
					testSuite = new SoapUITestSuiteStruct();
					testSuiteMap.put(testCase.getApiName(), testSuite);
					testCases.add(testSuite);
					File testPlan = new File(testPlanFilePath);
					testSuite.setMicroServiceName(testPlan.getName());
				}
				testSuite.addTestCase(testCase);
				testSuite.setApiName(testCase.getApiName());

			}
		} finally {
			if (reader != null) {
				reader.close();
			}
		}
		return testCases;
	}
}
