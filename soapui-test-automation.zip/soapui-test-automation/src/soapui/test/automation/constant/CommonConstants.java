package soapui.test.automation.constant;

import java.util.HashMap;
import java.util.Map;

public final class CommonConstants {

	public static Map<String, Integer> testPlanColIndex = new HashMap<String, Integer>();
	public static final String TESTCASE_ID = "TEST_Case_ID";
	public static final String TEST_STEP = "TEST_Step";
	public static final String API = "API";
	public static final String URL = "URL";
	public static final String HTTP_METHOD = "HTTP_Method";
	public static final String REQUEST_PARAMETERS = "Request_Parameters";
	public static final String REQUEST_BODY = "Request_Body";
	public static final String HEADERS = "Headers";
	public static final String AUTH = "Auth";
	public static final String HTTP_RESPONSE_CODE = "HTTP_Response_code";
	public static final String XML_FILE_EXTENSION = ".XML";
	public static final String CSV_FILE_EXTENSION = ".CSV";
	public static final String JSON_FILE_EXTENSION = ".JSON";
	public static final String TESTPLAN_FILE_EXTENSION = "_TESTPLAN.CSV";
	public static final String VALID_HTTP_STATUS_CODE_CONFIG = "<codes xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:con=\"http://eviware.com/soapui/config\">%s</codes>";
	public static final String PROJECT_ENDPOINT_KEY = "${#Project#endpoint}";
	public static final char COLON = ':';
	public static final String HTTP_STATUS_CODES_KEY = "codes";
	public static final String CREATE_CONFIGURATION_METHOD_NAME = "createConfiguration";
	public static final String PROJECT_PROP = "${#Project#";
	public static final String TESTPLANCOLUMNHEADER = "TEST_Case_ID,TEST_Step,API,URL,HTTP_Method,Request_Parameters,Request_Body,Headers,Auth,HTTP_Response_code";
	public static final String ONLYPOSITIVE = "OnlyPositive";
	public static final String TEST_TYPE_KEY = "TestCaseType";
	public static final String INPUT_TYPE_SWAGGERJSON = "SwaggerJSON";
	public static final String INPUT_TYPE_CURL = "CURL";
	public static final String MICROSERVICENAME_KEY = "MicroServiceName";

	public enum ParameterType {
		BODY, HEADER, PATH, QUERY, COOKIE, FORMDATA
	}

	static {
		int index = 0;
		testPlanColIndex.put(TESTCASE_ID, index++);
		testPlanColIndex.put(TEST_STEP, index++);
		testPlanColIndex.put(API, index++);
		testPlanColIndex.put(URL, index++);
		testPlanColIndex.put(HTTP_METHOD, index++);
		testPlanColIndex.put(REQUEST_PARAMETERS, index++);
		testPlanColIndex.put(REQUEST_BODY, index++);
		testPlanColIndex.put(HEADERS, index++);
		testPlanColIndex.put(AUTH, index++);
		testPlanColIndex.put(HTTP_RESPONSE_CODE, index++);
	}
}
